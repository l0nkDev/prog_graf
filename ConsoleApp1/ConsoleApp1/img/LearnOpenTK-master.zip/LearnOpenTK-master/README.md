# LearnOpenTK
For a more comprehensive written tutorial go to the [Learn section of OpenTK.net](https://opentk.net/learn/index.html) site.

A port of [the tutorials at LearnOpenGL](https://learnopengl.com/) to C#/OpenTK.
These tutorials serve as a complement to the website tutorial and contains working samples of the different chapters.

